import pandas as pd
import math
import numpy as np
import csv




linkdata = pd.read_csv('F:\connectdata\linknumber\Rw_v10_20_linknum.csv')
print(linkdata.dtypes)


# data = pd.read_csv('./aodv40.csv')

# name= ['timestep','nodeid','xla','yla']
# timedata=  pd.DataFrame(data=data)
# timedata.columns=name

# print(timedata.loc[0]['xla'])# 取一值

# file = 'data.csv'
# fi = open(file, 'w', encoding='utf-8',newline='')
# fi.close( )

def write_csv(datalist, path):
    test = pd.DataFrame(data=datalist)
    test.to_csv(path)
    return test


l3 = []

l1 = linkdata.loc[:, 'ts']
print(type(l1))
x = linkdata.shape[0]

print(x)
l3 = l1.tolist()

link_num = [0] * 800
# # print (timetimedata_list)
for i in range(0, 800):
    m = 0
    for j in range(0, x):
        a = l3[j]
        # print(a)
        if a == i:
            m = m + 1
            link_num[i] = m
#
# print(link_num)

path= 'F:\connectdata\link_sec\Rw_v10-20.csv'
write_csv(link_num,path)

