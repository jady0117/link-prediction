import pandas as pd
import math
import numpy as np
import csv

class Point():
    def __init__(self, x1, y1, x2, y2):
        self.x1 = x1
        self.y1 = y1
        self.x2 = x2
        self.y2 = y2


class Line(Point):
    def __init__(self, x1, y1, x2, y2):
        super().__init__(x1, y1, x2, y2)

    def getlen(self):
        dis = math.sqrt(math.pow((self.x1 - self.x2), 2) + math.pow((self.y1 - self.y2), 2))
        # math.pow(底数x,指数y)
        return dis

timedata = pd.read_csv('./rw.csv')
# data = pd.read_csv('./aodv40.csv')

# name= ['timestep','nodeid','xla','yla']
# timedata=  pd.DataFrame(data=data)
# timedata.columns=name

# print(timedata.loc[0]['xla'])


# file = 'data.csv'
# fi = open(file, 'w', encoding='utf-8',newline='')
# fi.close( )

def write_csv(datalist,path):
    test=pd.DataFrame(data=datalist)
    test.to_csv(path)
    return test




path= 'F:\connectdata\Testw1.csv'
node = 40 #
# s = int(timedata.shape[0] / node)# 800s
# print(timedata.shape[0])
# print(s)
# a = list(timedata)
timedata_list=[]


for i in range(0, 51):
    for j in range(0, 40):# 0-39
        for k in range(j+1, 40):
            x1 = timedata.loc[51*j+i]['xla']
            y1 = timedata.loc[51*j+i]['yla']
            x2 = timedata.loc[51*k+i]['xla']
            y2 = timedata.loc[51*k+i]['yla']
            L = Line(x1, y1, x2, y2)
            distance = L.getlen()
            if distance <= 250:
                df1 = timedata.loc[51*j+i].values.tolist()
                df2 = timedata.loc[51*k+i].values.tolist()

                nodelist2=[]
                nodelist2=list(df1)
                # print(nodelist2)
                timedata_list.append(nodelist2)
                # print(timedata_list)
                write_csv(timedata_list,path)










