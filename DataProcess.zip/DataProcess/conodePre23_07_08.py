import pandas as pd
import math
import numpy as np
import csv

def write_csv(datalist,path):
    test=pd.DataFrame(data=datalist)
    test.to_csv(path,index=False)
    return test



path= 'F:\connectdata\GM4080Node.csv'
# path= 'F:\connectdata\Rw20_link_num.csv'
node = 40 # 
# s = int(timedata.shape[0] / node)# 800s
# print(timedata.shape[0])
# print(s)
# a = list(timedata)
timedata_list=[]
# m=51
# id=0

for j in range(0, 41):  # 0-39

    df1=int(j)
    df2 = int(j+1)
    # df1= str(df1)
    # df2 = str(df2)
    # tim=str(i)
    str3= f'_id:{df2}' + '/'
    str4 = f'name:{df1}'+'/'
    # r4=eval(str4)
    # str5 = f'{df1} {df2} 1 {tim}'

    str6 =f'idx:{j}'+'.'

    # nodelist2=[]
    # nodelist2 = nodelist2.
    # nodelist2=list(df1)
    # print(nodelist2)
    a=str3.replace('"','')
    b=str4.replace('"','')
    c=str6.replace('"','')

    timedata_list.append(a)
    timedata_list.append(b)
    timedata_list.append(c)
    # print(timedata_list)
    write_csv(timedata_list,path)






