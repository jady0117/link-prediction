import pandas as pd
import math
import numpy as np
import csv# 计算两点间的距离
class Point():
    def __init__(self, x1, y1, x2, y2):
        self.x1 = x1
        self.y1 = y1
        self.x2 = x2
        self.y2 = y2


class Line(Point):
    def __init__(self, x1, y1, x2, y2):
        super().__init__(x1, y1, x2, y2)

    def getlen(self):
        dis = math.sqrt(math.pow((self.x1 - self.x2), 2) + math.pow((self.y1 - self.y2), 2)) # math.pow(底数x,指数y)
        return dis

timedata = pd.read_csv('./rw4080.csv')

def write_csv(datalist,path):
    test=pd.DataFrame(data=datalist)
    test.to_csv(path,index=False)
    return test



path= 'F:\connectdata\Rw4080link.csv'
# path= 'F:\connectdata\Rw20_link_num.csv'
node = 40 
# s = int(timedata.shape[0] / node)# 800s
# print(timedata.shape[0])
# print(s)
# a = list(timedata)
timedata_list=[]
m=51
id=0
for i in range(0, 901):
    for j in range(0, 40):  # 0-39
        for k in range(j + 1, 40):
            x1 = timedata.loc[901 * j + i]['xla']
            y1 = timedata.loc[901 * j + i]['yla']
            x2 = timedata.loc[901 * k + i]['xla']
            y2 = timedata.loc[901 * k + i]['yla']
            L = Line(x1, y1, x2, y2)
            distance = L.getlen()

            if distance <= 250:
                df1 = timedata.loc[901 * j + i]['nodeid'].tolist()
                df2 = timedata.loc[901 * k + i]['nodeid'].tolist()

                df1=int(df1)
                df2 = int(df2)
                # df1= str(df1)
                # df2 = str(df2)
                # tim=str(i)
                str4 = f'name:{df1}_{df2}'+'/'
                # r4=eval(str4)
                # str5 = f'{df1} {df2} 1 {tim}'
                # str5 = f'time:{i}'+'.'
                str5 = f'time:{i}_{i}' + '.'
                id=id+1
                # sid=str(id)
                str6 =f'_id:{id}'+'/'

                # nodelist2=[]
                # nodelist2 = nodelist2.
                # nodelist2=list(df1)
                # print(nodelist2)
                a=str4.replace('"','')
                b=str5.replace('"','')
                c=str6.replace('"','')

                timedata_list.append(c)
                timedata_list.append(a)
                timedata_list.append(b)
                # print(timedata_list)
                write_csv(timedata_list,path)






