from matplotlib import pyplot as plt
import pandas as pd
import math
import numpy as np
import csv


linkdata = pd.read_csv('F:/connectdata/data_bonnimotion/1.csv')

z1 = linkdata.loc[:, 'ts']

zz = z1.tolist()
x1 = linkdata.loc[:, 'xla']

xx = x1.tolist()
y1 = linkdata.loc[:, 'yla']

yy = x1.tolist()

from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter
import numpy as np
fig = plt.figure()
ax = fig.gca(projection='3d')

length = 100

X=xx
Y=yy

X, Y = np.meshgrid(X, Y)
Z=zz
surf = ax.plot_surface(X, Y, Z, cmap=cm.coolwarm,
                       linewidth=0, antialiased=False)

# Customize the z axis.
ax.set_zlim(0, 800)
ax.zaxis.set_major_locator(LinearLocator(10))
ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))


fig.colorbar(surf, shrink=0.5, aspect=5)

plt.show()