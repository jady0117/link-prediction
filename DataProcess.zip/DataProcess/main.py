import pandas as pd
import math
import numpy as np
class Point():
    def __init__(self, x1, y1, x2, y2):
        self.x1 = x1
        self.y1 = y1
        self.x2 = x2
        self.y2 = y2


class Line(Point):
    def __init__(self, x1, y1, x2, y2):
        super().__init__(x1, y1, x2, y2)

    def getlen(self):
        dis = math.sqrt(math.pow((self.x1 - self.x2), 2) + math.pow((self.y1 - self.y2), 2))
     
        return dis
L = Line(1,0,1,1)
distance= L.getlen()

#print(distance)

timedata = pd.read_csv('./rw.csv')
# data = pd.read_csv('./aodv40.csv')
# name= ['timestep','nodeid','xla','yla']
# timedata=  pd.DataFrame(data=data)
# timedata.columns=name

# print(timedata)
node = 40 
s=50
# s = int(timedata.shape[0] / node)# 800
# print(s)
a = list(timedata)
timedata_list=[]
for i in range(0, s):
    # print(timedata[i])
    b = 0
    for j in range(0, node):
        for a in range(1,node+1-j):

            x1 = timedata.loc[j][2]
            y1 = timedata.loc[j][3]
            x2 = timedata.loc[j+a][2]
            y2 = timedata.loc[j + a][3]
            L = Line(x1, y1, x2, y2)
            distance = L.getlen()
            if distance <= 250:
                timedata_list.append([i,j,timedata.loc[j][2]])
            print()
            b += 1
    print(b)
    #i = i + 1


# #
#
print(timedata_list)