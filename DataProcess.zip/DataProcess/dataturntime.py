import pandas as pd
import math
import numpy as np
from datetime import datetime
from dateutil.parser import parse

#读取CVS数据，并为每列加上标签
timedata = pd.read_csv('./data.csv')


# timedata['tim']  = timedata['time']+1
# timedata['tim'] = timedata['tim'].datetime.strftime('-%d/%m/%Y-')

# # timedata['time'] = timedata['time'] .astype('datetime64[ns]')
# timedata['time']=timedata['time'].astype('int')
# timedata['time']=pd.to_datetime(timedata['time'])

time_data = pd.to_datetime(timedata['tim'])
timedata['tim'] = time_data
print(timedata.dtypes)

# time_data1=pd.datetime.strftime(timedata['tim'],format='%d/%m/%Y')
# timedata['tim'] = time_data1
# timedata['time'] = timedata['time'].apply(parse)
print(timedata.dtypes)









# data = pd.read_csv('./aodv40.csv')
# 每列的数据标签
# name= ['timestep','nodeid','xla','yla']
# timedata=  pd.DataFrame(data=data)
# timedata.columns=name
#
# # print(timedata)
# node = 40 # j节点数
# s = int(timedata.shape[0] / node)# 800s
# a = list(timedata)
# timedata_list=[]
# for i in range(0, s):
#     # print(timedata[i])
#     b = 0
#     for j in range(0, node):
#         for a in range(1,node+1-j):
#
#             x1 = timedata.loc[j][2]
#             y1 = timedata.loc[j][3]
#             x2 = timedata.loc[j+a][2]
#             y2 = timedata.loc[j + a][3]
#             L = Line(x1, y1, x2, y2)
#             distance = L.getlen()
#             if distance <= 250:
#                 timedata_list.append(i,j,timedata.loc[j][2],)
#             print()
#             b += 1
#     print(b)
#     #i = i + 1
#
#
# # #
# #
# # print(timedata)